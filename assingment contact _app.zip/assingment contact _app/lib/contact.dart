class Contact {
  final String name;
  final String email;
  final String phone;
  final String image;

  Contact({
    required this.name,
    required this.email,
    required this.phone,
    required this.image,
  });
}
